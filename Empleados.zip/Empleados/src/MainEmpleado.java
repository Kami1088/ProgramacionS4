import javax.swing.*;
import java.time.LocalDate;
public class MainEmpleado {
    public static void main(String[] args) {
        String cedula = JOptionPane.showInputDialog("Ingrese la cédula del empleado:");
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del empleado:");
        String apellido = JOptionPane.showInputDialog("Ingrese el apellido del empleado:");
        String genero = JOptionPane.showInputDialog("Ingrese el género del empleado:");
        double salario = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el salario del empleado:"));
        LocalDate fechaNacimiento = LocalDate.parse(JOptionPane.showInputDialog("Ingrese la fecha de nacimiento (AAAA-MM-DD):"));
        LocalDate fechaIngreso = LocalDate.parse(JOptionPane.showInputDialog("Ingrese la fecha de ingreso (AAAA-MM-DD):"));

        Empleado empleado = new Empleado(cedula, nombre, apellido, genero, salario, fechaNacimiento, fechaIngreso);

        // Opción para modificar salario
        int opcion = JOptionPane.showConfirmDialog(null, "¿Desea modificar el salario del empleado?", "Modificar Salario", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            double nuevoSalario = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el nuevo salario:"));
            empleado.modificarSalario(nuevoSalario);
        }

        empleado.showInfo();
    }
}