import javax.swing.*;
class Rectangulo {
    private double largo;
    private double ancho;

    public Rectangulo(double largo, double ancho) {
        this.largo = largo;
        this.ancho = ancho;
    }

    public double calcularArea() {
        return largo * ancho;
    }

    public double calcularPerimetro() {
        return 2 * (largo + ancho);
    }

    public void showInfo() {
        JOptionPane.showMessageDialog(null, "Área del rectángulo: " + calcularArea() +
                "\nPerímetro del rectángulo: " + calcularPerimetro());
    }
}