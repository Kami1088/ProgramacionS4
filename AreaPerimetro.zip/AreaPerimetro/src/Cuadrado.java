import javax.swing.*;

class Cuadrado {
    private double lado;

    public Cuadrado(double lado) {
        this.lado = lado;
    }

    public double calcularArea() {
        return lado * lado;
    }

    public double calcularPerimetro() {
        return 4 * lado;
    }

    public void showInfo() {
        JOptionPane.showMessageDialog(null, "Área del cuadrado: " + calcularArea() +
                "\nPerímetro del cuadrado: " + calcularPerimetro());
    }
}