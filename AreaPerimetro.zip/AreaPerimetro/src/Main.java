import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        String opcion = JOptionPane.showInputDialog("Seleccione la figura que desea calcular:\n" +
                "1. Triángulo\n" +
                "2. Cuadrado\n" +
                "3. Rectángulo");
        int figura = Integer.parseInt(opcion);

        switch (figura) {
            case 1:
                double base = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la base del triángulo:"));
                double altura = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la altura del triángulo:"));
                double lado1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el primer lado del triángulo:"));
                double lado2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el segundo lado del triángulo:"));
                double lado3 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el tercer lado del triángulo:"));
                Triangulo triangulo = new Triangulo(base, altura, lado1, lado2, lado3);
                triangulo.showInfo();
                break;

            case 2:
                double lado = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el lado del cuadrado:"));
                Cuadrado cuadrado = new Cuadrado(lado);
                cuadrado.showInfo();
                break;

            case 3:
                double largo = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el largo del rectángulo:"));
                double ancho = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el ancho del rectángulo:"));
                Rectangulo rectangulo = new Rectangulo(largo, ancho);
                rectangulo.showInfo();
                break;

            default:
                JOptionPane.showMessageDialog(null, "Opción no válida.");
                break;
        }
    }
}