import javax.swing.JOptionPane;

class Vehiculo {
    private String numeroMotor;
    private int numVentanas;
    private int numPuertas;
    private String marca;
    private String modelo;
    private double kilometrajeInicial;
    private double kilometrajeFinal;

    public Vehiculo(String numeroMotor, int numVentanas, int numPuertas, String marca, String modelo, double kilometrajeInicial, double kilometrajeFinal) {
        this.numeroMotor = numeroMotor;
        this.numVentanas = numVentanas;
        this.numPuertas = numPuertas;
        this.marca = marca;
        this.modelo = modelo;
        this.kilometrajeInicial = kilometrajeInicial;
        this.kilometrajeFinal = kilometrajeFinal;
    }

    public double calcularKilometrosRecorridos() {
        return kilometrajeFinal - kilometrajeInicial;
    }

    public void showInfo() {
        JOptionPane.showMessageDialog(null, "Número de Motor: " + numeroMotor +
                "\nNúmero de Ventanas: " + numVentanas +
                "\nNúmero de Puertas: " + numPuertas +
                "\nMarca: " + marca +
                "\nModelo: " + modelo +
                "\nKilómetros recorridos: " + calcularKilometrosRecorridos());
    }
}


