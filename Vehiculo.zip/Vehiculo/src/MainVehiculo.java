import javax.swing.*;

public class MainVehiculo {
    public static void main(String[] args) {
        String numeroMotor = JOptionPane.showInputDialog("Ingrese el número de motor:");
        int numVentanas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de ventanas:"));
        int numPuertas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de puertas:"));
        String marca = JOptionPane.showInputDialog("Ingrese la marca del vehículo:");
        String modelo = JOptionPane.showInputDialog("Ingrese el modelo del vehículo:");
        double kilometrajeInicial = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el kilometraje inicial:"));
        double kilometrajeFinal = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el kilometraje final:"));

        Vehiculo vehiculo = new Vehiculo(numeroMotor, numVentanas, numPuertas, marca, modelo, kilometrajeInicial, kilometrajeFinal);
        vehiculo.showInfo();
    }
}