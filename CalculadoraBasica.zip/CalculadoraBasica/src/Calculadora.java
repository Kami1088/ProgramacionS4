
import javax.swing.JOptionPane;
class Calculadora {
    public double sumar(double a, double b) {
        return a + b;
    }

    public double restar(double a, double b) {
        return a - b;
    }

    public double multiplicar(double a, double b) {
        return a * b;
    }

    public double dividir(double a, double b) {
        if (b != 0) return a / b;
        else {
            JOptionPane.showMessageDialog(null, "No se puede dividir por cero.");
            return 0;
        }
    }

    public void showCalculadora() {
        double num1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese primer número:"));
        double num2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese segundo número:"));

        JOptionPane.showMessageDialog(null, "Suma: " + sumar(num1, num2) +
                "\nResta: " + restar(num1, num2) +
                "\nMultiplicación: " + multiplicar(num1, num2) +
                "\nDivisión: " + dividir(num1, num2));
    }
}