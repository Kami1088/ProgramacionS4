import javax.swing.*;

public class MainProducto {
    public static void main(String[] args) {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto:");
        double precio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del producto:"));
        String tieneIVAInput = JOptionPane.showInputDialog("¿El producto tiene IVA? (sí/no):");
        boolean tieneIVA = tieneIVAInput.equalsIgnoreCase("sí");

        Producto producto = new Producto(nombre, precio, tieneIVA);
        producto.showInfo();
    }
}